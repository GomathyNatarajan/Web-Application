package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.security.*;
import java.math.*;

public class Analysis {
	private static Connection connect = null;
	private static String host = "localhost";
	private static String database = "gn79";
	private static String username = "root";
	private static String password = "Positive";

	public static Connection getConnection() {
		if (connect == null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				String conn_string = "jdbc:mysql://" + host + "/" + database;
				Connection connect = DriverManager.getConnection(conn_string, username, password);
				return connect;
			} catch (Exception ex) {
				return null;
				// ex.printStackTrace();
			}
		} else {
			return connect;
		}
	}

	public TotalCases getTotalCases() {
		
		TotalCases tc = null;
		String pc_tc = null;
		String nc_tc = null;
		
		String sql_pc = "SELECT COUNT(Email) AS PCCount FROM TestResult WHERE TestResult='Positive'";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_pc);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					pc_tc = rs.getString("PCCount");
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		String sql_nc = "SELECT COUNT(Email) AS NCCount FROM TestResult WHERE TestResult='Negative'";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_nc);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					nc_tc = rs.getString("NCCount");
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		tc = new TotalCases(pc_tc, nc_tc);
		return tc;
	}
	
	public List<Count> getPositiveCasesbyPC()
	{
		ArrayList<Count> c = new ArrayList<Count>();
		
		String sql_pst_pc = "SELECT COUNT(Email) AS PPCCount, Postcode FROM TestResult WHERE TestResult='Positive' GROUP BY Postcode";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_pst_pc);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					String pst_pc = rs.getString("PPCCount");
					String pst_code = rs.getString("Postcode");
					String category = "PCGP";
					c.add(new Count(category, pst_code, pst_pc));
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return c;
	}
	public List<Count> getPositiveCasesbyAge()
	{
		ArrayList<Count> c = new ArrayList<Count>();
		ArrayList<Count> r = new ArrayList<Count>();
		
		String age_pc = null;
		String age = null;
		String category = null;
		
		String sql_pst_age = "SELECT COUNT(Email) AS APCCount, Age FROM TestResult WHERE TestResult='Positive' GROUP BY Age";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_pst_age);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					age_pc = rs.getString("APCCount");
					age = rs.getString("Age");
					category = "PCGA";
					c.add(new Count(category, age, age_pc));
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		if (c != null)
		{
			int g1 = 0;
			int g2 = 0;
			int g3 = 0;
			int g4 = 0;
			int g5 = 0;
			for(Count count : c)
			{
				int ageValue = Integer.parseInt(count.getname());
				int ageCount = Integer.parseInt(count.getvalue());
				if(ageValue < 21)
				{
				g1 = g1 + ageCount;
				}
				else if(ageValue >= 21 && ageValue < 41)
				{
					g2 = g2 + ageCount;	
				}
				else if(ageValue >= 41 && ageValue < 61)
				{
					g3 = g3 + ageCount;
				}
				else if(ageValue >= 61 && ageValue < 81)
				{
					g4 = g4 + ageCount;
				}
				else if(ageValue >= 81 && ageValue < 101)
				{
					g5 = g5 + ageCount;
				}
			}
			age = "0 - 20";
			age_pc = String.valueOf(g1);
			category = "PCGA";
			r.add(new Count(category, age, age_pc));
			age = "21 - 40";
			age_pc = String.valueOf(g2);
			category = "PCGA";
			r.add(new Count(category, age, age_pc));
			age = "41 - 60";
			age_pc = String.valueOf(g3);
			category = "PCGA";
			r.add(new Count(category, age, age_pc));
			age = "61 - 80";
			age_pc = String.valueOf(g4);
			category = "PCGA";
			r.add(new Count(category, age, age_pc));
			age = "81 - 100";
			age_pc= String.valueOf(g5);
			category = "PCGA";
			r.add(new Count(category, age, age_pc));
			
		}
		return r;
	}
	
	public List<Count> getInfectionRatebyPC()
	{
		ArrayList<Count> pc_pst = new ArrayList<Count>();
		ArrayList<Count> result = new ArrayList<Count>();
		String sql_pst = "SELECT COUNT(Email) AS PTCount, Postcode FROM TestResult GROUP BY Postcode";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_pst);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					String pst_tc = rs.getString("PTCount");
					String pst_code = rs.getString("Postcode");
					String category = "TCBPC";
				    pc_pst = (ArrayList<Count>) getPositiveCasesbyPC();
					for(Count pc : pc_pst)
					{
						String name = pc.getname();
						double count = Double.parseDouble(pc.getvalue());
						if(name.equals(pst_code)) {
							double a = Double.parseDouble(pst_tc);
							double value = (count/a) * 100 ;
							String out = String.valueOf(value); 
							result.add(new Count(category, name, out));
						}
					}
				    
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return result;
	}
	
	public List<Count> getInfectionRatebyAge()
	{
		ArrayList<Count> pc_age = new ArrayList<Count>();
		ArrayList<Count> result = new ArrayList<Count>();
		ArrayList<Count> c = new ArrayList<Count>();
		ArrayList<Count> r = new ArrayList<Count>();
		
		String age_tc = null;
		String age = null;
		String category = null;
		
		String sql_age = "SELECT COUNT(Email) AS PTCount, Age FROM TestResult GROUP BY Age";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_age);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					age_tc = rs.getString("PTCount");
					age = rs.getString("Age");
					category = "TCBA";
					c.add(new Count(category, age, age_tc));
				    
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		
		if (c != null)
		{
			int g1 = 0;
			int g2 = 0;
			int g3 = 0;
			int g4 = 0;
			int g5 = 0;
			for(Count count : c)
			{
				int ageValue = Integer.parseInt(count.getname());
				int ageCount = Integer.parseInt(count.getvalue());
				if(ageValue < 21)
				{
				g1 = g1 + ageCount;
				}
				else if(ageValue >= 21 && ageValue < 41)
				{
					g2 = g2 + ageCount;	
				}
				else if(ageValue >= 41 && ageValue < 61)
				{
					g3 = g3 + ageCount;
				}
				else if(ageValue >= 61 && ageValue < 81)
				{
					g4 = g4 + ageCount;
				}
				else if(ageValue >= 81 && ageValue < 101)
				{
					g5 = g5 + ageCount;
				}
			}
			
			age = "0 - 20";
			age_tc = String.valueOf(g1);
			category = "TCBA";
			r.add(new Count(category, age, age_tc));
			age = "21 - 40";
			age_tc = String.valueOf(g2);
			category = "TCBA";
			r.add(new Count(category, age, age_tc));
			age = "41 - 60";
			age_tc = String.valueOf(g3);
			category = "TCBA";
			r.add(new Count(category, age, age_tc));
			age = "61 - 80";
			age_tc = String.valueOf(g4);
			category = "TCBA";
			r.add(new Count(category, age, age_tc));
			age = "81 - 100";
			age_tc= String.valueOf(g5);
			category = "TCBA";
			r.add(new Count(category, age, age_tc));	
		}
		pc_age = (ArrayList<Count>) getPositiveCasesbyAge();
		for(Count tc : r)
		{
		for(Count pc : pc_age)	
		{
			String name = pc.getname();
			double count = Double.parseDouble(pc.getvalue());
			if(name.equals(tc.getname())) {
				double a = Double.parseDouble(tc.getvalue());
				double value = (count/a) * 100 ;
				String out = String.valueOf(value);
				if (out.equals("NaN"))
				{
					out = "0";
				}
				System.out.println("PositiveCases - " + count);
				System.out.println("Total Count - " + a);
				result.add(new Count(category, name, out));
			}
		}
		}
		
		return result;
	}

	
	
}
