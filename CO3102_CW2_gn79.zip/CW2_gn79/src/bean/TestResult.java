package bean;

public class TestResult {
	
	public TestResult(String Age, String Postcode, String TestResult) {
		super();
		this.Age = Age;
		this.Postcode = Postcode;
		this.TestResult = TestResult;
	}
	public String getAge() {
		return Age;
	}
	public String getPostcode() {
		return Postcode;
	}
	public String getTestResult() {
		return TestResult;
	}
	public void setAge(String Age)
	{
		this.Age = Age;
	}
	public void setPostCode(String Postcode)
	{
		this.Postcode = Postcode;
	}
	public void setTestResult(String TestResult)
	{
		this.TestResult = TestResult;
	}
	String Age;
	String Postcode;
	String TestResult;
	

}
