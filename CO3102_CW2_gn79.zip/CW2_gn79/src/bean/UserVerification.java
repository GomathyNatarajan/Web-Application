package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.security.*;
import java.math.*;
import java.security.MessageDigest;

public class UserVerification {

	private static Connection connect = null;
	private static String host = "localhost";
	private static String database = "gn79";
	private static String username = "root";
	private static String password = "Positive";

	public static Connection getConnection() {
		if (connect == null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				String conn_string = "jdbc:mysql://" + host + "/" + database;
				Connection connect = DriverManager.getConnection(conn_string, username, password);
				return connect;
			} catch (Exception ex) {
				return null;
				// ex.printStackTrace();
			}
		} else {
			return connect;
		}
	}

	public User checkUser(String user, String password) {
		String sql = "SELECT * from Admin WHERE Username=? AND PasswordHash=?";
		User u = null;
		String passwordHash = get_SHA_256_SecurePassword(password);
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql);) {
			pstmt.setString(1, user);
			pstmt.setString(2, passwordHash);
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					String uname = rs.getString("Username");
					String pass = rs.getString("PasswordHash");
					u = new User(uname, pass);
					break;
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		System.out.println(u);
		return u;
	}

	public static String get_SHA_256_SecurePassword(String password) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(password.getBytes());
			return bytesToHex(md.digest());
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	private static String bytesToHex(byte[] bytes) {
		StringBuffer result = new StringBuffer();
		for (byte b : bytes)
			result.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
		return result.toString();
	}

	public TTN validateTTN(String tnn) {
		TTN t = null;
		String sql = "SELECT * from HomeTestKit WHERE TNN_Code=?";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql);) {
			pstmt.setString(1, tnn);
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					String tnn_no = rs.getString("TNN_Code");
					String used = rs.getString("used");
					t = new TTN(tnn_no, used);
					break;
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		System.out.println(t);
		return t;
	}
	
	public Email ValidateEmail(String email) {
		Email e = null;
		String sql = "SELECT * from TestResult WHERE Email=?";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql);) {
			pstmt.setString(1, email);
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					String email1 = rs.getString("Email");
					e = new Email(email1);
					break;
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return e;
	}

	public boolean UpdateHomeTestKit(String tnn)
		 {
			boolean t = false;
			String sql="UPDATE HomeTestKit SET used='1' WHERE TNN_Code=?";
			try( Connection connect = getConnection(); 
			    	 PreparedStatement pstmt = connect.prepareStatement(sql);
		    		)
			{
				pstmt.setString(1,tnn);
				pstmt.execute();
				t = true;
				
			}
			catch(SQLException ex){
	    		ex.printStackTrace();	
	    	}
			
			System.out.println(t);
			return t;
		 }
	public boolean UpdateTestResult(String email, String fullname, int age, String gender, String address, String postcode, String ttn_no, String result )
	 {
		boolean r = false;
		System.out.println(result);
		String sql="INSERT INTO TestResult VALUES(?,?,?,?,?,?,?,?)";
		try( Connection connect = getConnection(); 
		    	 PreparedStatement pstmt = connect.prepareStatement(sql);
	    		)
		{
			pstmt.setString(1,email);
			pstmt.setString(2,fullname);
			pstmt.setInt(3,age);
			pstmt.setString(4,gender);
			pstmt.setString(5,address);
			pstmt.setString(6,postcode);
			pstmt.setString(7,ttn_no);
			pstmt.setString(8,result);
			pstmt.execute();
			System.out.println(pstmt.toString());
			r = true;
		}
		catch(SQLException ex){
    		ex.printStackTrace();	
    	}
		return r;
	 }

}
