package bean;

public class TotalCases {
	
	public TotalCases(String PCCount, String NCCount) {
		super();
		this.PCCount = PCCount;
		this.NCCount = NCCount;
		
	}
	public String getPCCount() {
		return PCCount;
	}
	public String getNCCount() {
		return NCCount;
	}
	public void setPCCount(String PCCount)
	{
		this.PCCount = PCCount;
	}
	public void setNCCount(String NCCount)
	{
		this.NCCount = NCCount;
	}
	String PCCount;
	String NCCount;
}
