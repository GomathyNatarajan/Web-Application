package bean;

public class TTN {
	
public TTN(String tnn, String used) {
	super();
	this.tnn = tnn;
	this.used = used;
	}
public String getTNN() {
	return tnn;
}
public void setTNN(String tnn) {
	this.tnn = tnn;
}
public String getUsed() {
	return used;
}
public void setUsed(String used) {
	this.used = used;
}

String tnn;
String used;
}
