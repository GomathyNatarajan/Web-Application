package bean;

public class Count {

	public Count(String category, String name, String value) {
		super();
		this.category = category;
		this.name = name;
		this.value = value;
		
	}
	public String getcategory() {
		return category;
	}
	public String getname() {
		return name;
	}
	public String getvalue() {
		return value;
	}
	public void setcategory(String category)
	{
		this.category = category;
	}
	public void setname(String name)
	{
		this.name = name;
	}
	public void setvalue(String value)
	{
		this.name = value;
	}
	String category;
	String name;
	String value;
}
