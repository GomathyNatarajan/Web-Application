package cw2_gn79;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Analysis;
import bean.Count;

public class InfectionRatePC extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		
		PrintWriter out = res.getWriter();
		Analysis dbOperator = new Analysis();
		List<Count> c;
		c = dbOperator.getInfectionRatebyPC();
		HttpSession se = req.getSession();
		if(c != null)
		{
			se.setAttribute("Count", c);
			res.sendRedirect("../InfectionRatePC.jsp");
		}
		else {
			res.sendRedirect("../error.jsp?errorid=4");
			out.close();
		}

	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}

