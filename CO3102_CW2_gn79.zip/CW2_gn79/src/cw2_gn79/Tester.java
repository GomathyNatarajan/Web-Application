package cw2_gn79;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.TTN;
import bean.UserVerification;
import bean.Email;

public class Tester extends HttpServlet {
	public void doGet(HttpServletRequest req, 
	        HttpServletResponse res) 
        throws ServletException, IOException {
		
		PrintWriter out = res.getWriter();	
		String email=req.getParameter("email");
		String fullname=req.getParameter("name");
		int age = Integer.parseInt(req.getParameter("age"));
		String gender = req.getParameter("gender");
		String address = req.getParameter("address");
		String postcode = req.getParameter("postcode");
		String TNN_no = req.getParameter("tnn");
		String test_res = req.getParameter("tstres");
		System.out.println(test_res);
		
		UserVerification dbOperator = new UserVerification();
		TTN t;
		t = dbOperator.validateTTN(TNN_no);
		Email e;
		e=dbOperator.ValidateEmail(email);	
		HttpSession se = req.getSession();

		String tnn = null;
		String used = null;
		if(t != null)
		{
			 tnn = t.getTNN();
			 used = t.getUsed();
		}
		if (tnn != null && used.equals("0"))  {
			System.out.println(tnn);
			System.out.println(used);	
		}
		
		if (tnn != null && used.equals("0"))  
		{
			if ( e == null)
			{
			boolean db,tr;
			tr = dbOperator.UpdateTestResult(email, fullname, age, gender, address, postcode, TNN_no, test_res);
			if (tr == true)
			{
			db = dbOperator.UpdateHomeTestKit(TNN_no);
			if (db == true)
			{
				res.sendRedirect("../success.jsp?id=1");
			}
			else {
				res.sendRedirect("../error.jsp?errorid=5");
				out.close();
			}
			}
			else {
				res.sendRedirect("../error.jsp?errorid=4");
				out.close();
			}
			
		}
			else {
				res.sendRedirect("../error.jsp?errorid=3");
				out.close();
			}
		}
		else { if(tnn != null && used.equals("1"))
		{
			res.sendRedirect("../error.jsp?errorid=2");
			out.close();
		}
		else
		{
			res.sendRedirect("../error.jsp?errorid=6");
			out.close();
		}
		}
		
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}
