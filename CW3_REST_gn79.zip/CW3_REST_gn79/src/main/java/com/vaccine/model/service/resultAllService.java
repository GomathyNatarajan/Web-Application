package com.vaccine.model.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.vaccine.model.allResult;
import com.vaccine.model.result;
import com.vaccine.model.vaccine;
import com.vaccine.model.volunteer;
import com.vaccine.model.error;
import com.vaccine.repository.vaccine_repository;
import com.vaccine.repository.volunteer_repository;
import com.google.gson.Gson;

@Component
public class resultAllService {

	@Autowired
	volunteer_repository vol_rep;
	
	@Autowired
	vaccine_repository vac_rep;

	
	public String getGroup_and_Dose(String group, float dose1) {
		
		String result_gd = new String();
		Gson json = new Gson();
		List<result> out = new ArrayList<result>();
		int total_vol_half_dose_A = 0,total_vol_half_dose_B = 0, total_positive_A_half = 0,total_vol_dose_A =0,total_vol_dose_B=0, 
				total_positive_A_dose = 0, total_positive_B_half = 0, total_positive_B_dose = 0, total = 0;
		String name = null, type = null, vg=null;
		float eff_rate = 0.0f, eff_rate_half=0.0f, dose=0.0f, a_half=0.0f, b_half=0.0f, a=0.0f, b=0.0f;
		List <vaccine> vaccine = vac_rep.findAll();
		
		for(vaccine vac : vaccine)
		{
			name = vac.getname();
			type = vac.gettype();
			vg = vac.getvaccineGroup();
			
			List<volunteer> vol = vol_rep.findByVaccineGroup(vg);
		
			for(volunteer v : vol)
			{
				
				if(v.getDose()==dose1) {
				if(v.getvaccineGroup().equals("A") && v.getDose()==0.5f)
				{
					total_vol_half_dose_A++;
					System.out.println(total_vol_half_dose_A);
					if(v.getInfected().equals("Positive")) total_positive_A_half++;total++;
					System.out.println(total_positive_A_half);
				}
				if(v.getvaccineGroup().equals("B") && v.getDose()==0.5f)
				{
					total_vol_half_dose_B++;
					if(v.getInfected().equals("Positive")) total_positive_B_half++;total++;
				}
				if(v.getvaccineGroup().equals("A") && v.getDose()==1.0f)
				{
					total_vol_dose_A++;
					if(v.getInfected().equals("Positive")) total_positive_A_dose++;total++;
				}
				if(v.getvaccineGroup().equals("B") && v.getDose()==1.0f)
				{
					total_vol_dose_B++;
					if(v.getInfected().equals("Positive")) total_positive_B_dose++;total++;
				}
				}
			}
			if(total_vol_half_dose_A != 0) {
				Map<String, Integer> result = new TreeMap<>();
				result.put("Volunteer", total_vol_half_dose_A);
				result.put("confirm_positive", total_positive_A_half);
				dose=0.5f;
				System.out.println(result);
				if(vg.equals(group))
				{
				out.add(new result(name, type, vg, dose, eff_rate, result));
				}
				a_half=total_positive_A_half;
				total_positive_A_half = 0;
				total_vol_half_dose_A = 0;
				
			}
			if(total_vol_half_dose_B !=0) {
				Map<String, Integer> result = new TreeMap<>();
				result.put("Volunteer", total_vol_half_dose_B);
				result.put("confirm_positive", total_positive_B_half);
				dose=0.5f;
				b_half=total_positive_B_half;
				if(a_half>b_half)eff_rate_half=(a_half-b_half)/a_half;
				if(a_half<b_half)eff_rate_half=((b_half-a_half)/b_half);
				if(vg.equals(group))
				{
				out.add(new result(name, type, vg, dose, eff_rate_half, result));
				}
				total_positive_B_half = 0;
				total_vol_half_dose_B = 0;
				
			}
			
			if(total_vol_dose_A !=0) {
				Map<String, Integer> result = new TreeMap<>();
				result.put("Volunteer", total_vol_dose_A);
				result.put("confirm_positive", total_positive_A_dose);
				dose=1.0f;
				if(vg.equals(group))
				{
				out.add(new result(name, type, vg, dose, eff_rate, result));
				}
				a=total_positive_A_dose;
				total_positive_A_dose = 0;
				total_vol_dose_A = 0;
			}
			if(total_vol_dose_B !=0) {
				Map<String, Integer> result = new TreeMap<>();
				result.put("Volunteer", total_vol_dose_B);
				result.put("confirm_positive", total_positive_B_dose);
				dose=1.0f;
				b=total_positive_B_dose;
				if(a>b)eff_rate=(a-b)/a;
				if(a<b)eff_rate=((b-a)/b);
				if(vg.equals(group))
				{
				out.add(new result(name, type, vg, dose, eff_rate, result));
								total_positive_A_dose = 0;
				}
				total_vol_dose_B = 0;
				name = null; type = null;
				
			}
		
								}
		
		for(result r : out) {
			if(r.getVaccineGroup().equals("A") && r.getDose() == 0.5f) r.setEfficiency_rate(eff_rate_half);
			if(r.getVaccineGroup().equals("A") && r.getDose() == 1.0f) r.setEfficiency_rate(eff_rate);
			if(r.getVaccineGroup().equals("B") && r.getDose() == 0.5f) r.setEfficiency_rate(0.0f);
			if(r.getVaccineGroup().equals("B") && r.getDose() == 1.0f) r.setEfficiency_rate(0.0f);
			result_gd += json.toJson(r);
		}
		if (total<10){
			
			error e = new error();
			e.setErrorMsg("Phase 3 Trial in progress, please wait.");
			result_gd = json.toJson(e);
			
		}
		return result_gd;
		}
		
		
		
	public String getallGroup() {
		
		String all_result = new String();
		
		ArrayList<allResult> output = new ArrayList<allResult>();
		Gson json = new Gson();
		
		int total_vol = 0, total_positive = 0,total =0; 
		float a = 0.0f, b = 0.0f;
		String VG = null, name = null, type = null;
		float eff_rate = 0.0f;
		
		List <vaccine> vaccines = vac_rep.findAll();

		for(vaccine vac : vaccines) {
			name = vac.getname();
			type = vac.gettype();
			VG = vac.getvaccineGroup();
			
		 List <volunteer> volunteers = vol_rep.findByVaccineGroup(VG);
		
		for(volunteer v : volunteers)
		{
			total_vol++;
			if("Positive".equals(v.getInfected())) total_positive++;
		}
		Map<String, Integer> result = new TreeMap<>();
		result.put("Volunteer", total_vol);
		result.put("confirm_positive", total_positive);
		if(VG.equals("A")) a=total_positive;
		if(VG.equals("B")) b=total_positive;
		if (a !=0 && b !=0)
			{
			if(a>b)eff_rate=(a-b)/a;
			if(a<b)eff_rate=((b-a)/b);
			}
		System.out.println(name + " " + type);
		output.add(new allResult(name, type, VG, eff_rate, result));
		total_positive = 0;
		total_vol = 0;
		}
		total = (int) (a+b);
		
		if (total<10){
			error e = new error();
			e.setErrorMsg("Phase 3 Trial in progress, please wait.");
			all_result = json.toJson(e);
			
		}

		if(total>10) {
		all_result = "[";
		for(allResult o : output) {
			if(o.getVaccineGroup().equals("A"))o.setEfficiency_rate(eff_rate);
			if(o.getVaccineGroup().equals("B"))o.setEfficiency_rate(0.0f);
			all_result += json.toJson(o);
		}
		all_result += "]";
		}
		return all_result;
	}
	
	
}
