package com.vaccine.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Volunteer")
public class volunteer {
	@Id
	@Column(name="email")
	String email;
	@Column(name="vaccineGroup")
	String vaccineGroup;
	@Column(name="dose")
	float dose;
	@Column(name="infected")
	String infected;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String Email)
	{
		this.email = email;
	}
	public String getvaccineGroup() {
		return vaccineGroup;
	}
	public void setvaccineGroup(String vaccineGroup)
	{
		this.vaccineGroup = vaccineGroup;
	}
	public float getDose() {
		return dose;
	}
	public void setDose(float Dose)
	{
		this.dose = dose;
	}
	public String getInfected() {
		return infected;
	}
	public void setInfected(String Infected){
		this.infected = infected;
	}

	}
