package com.vaccine.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Vaccine")
public class vaccine {
@Id
@Column(name="name")
private String name;
@Column(name="type")
private String type;
@Column(name="vaccineGroup")
private String vaccineGroup;

public String getvaccineGroup() {
	return vaccineGroup;
}
public void setvaccineGroup(String vaccineGroup)
{
	this.vaccineGroup = vaccineGroup;
}

public String getname() {
	return name;
}
public void setname(String name)
{
	this.name = name;
}

public String gettype() {
	return type;
}
public void settype(String type)
{
	this.type = type;
}

}


