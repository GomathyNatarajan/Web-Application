package com.vaccine.model;

import java.util.Map;

public class allResult {
	
	public allResult() {
		
	}
public allResult(String name, String type, String vaccineGroup, float efficiency_rate, Map<String, Integer> result) {
	this.name = name;
	this.type = type;
	this.vaccineGroup = vaccineGroup;
	this.efficiency_rate = efficiency_rate;
	this.result = result;
	}
public String getName() {
		return name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getVaccineGroup() {
		return vaccineGroup;
	}

	public float getEfficacy_rate() {
		return efficiency_rate;
	}
	public void setEfficiency_rate(float efficiency_rate) {
		this.efficiency_rate = efficiency_rate;
	}
	public Map<String, Integer> getResult() {
		return result;
	}



	
private String name;
private String type;
private String vaccineGroup;
private float efficiency_rate;
private Map<String,Integer> result;

}
