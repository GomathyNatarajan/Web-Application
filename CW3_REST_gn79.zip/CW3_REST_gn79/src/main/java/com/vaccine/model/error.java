package com.vaccine.model;

public class error {

	public error() {

	}

	public error(String error_message) {
		this.error_message = error_message;
	}

	public void setErrorMsg(String error_message) {
		this.error_message = error_message;
	}

	private String error_message;
}
