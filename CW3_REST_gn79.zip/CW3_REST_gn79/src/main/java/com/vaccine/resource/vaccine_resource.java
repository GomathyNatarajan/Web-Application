package com.vaccine.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.vaccine.model.allResult;
import com.vaccine.model.result;
import com.vaccine.model.service.resultAllService;

@RestController
@RequestMapping(value="/vaccine")
public class vaccine_resource {

	@Autowired
	resultAllService out;
	
	@RequestMapping(value="/all_result")
	public String getAll(){
			return out.getallGroup();

			}
	
	@RequestMapping(value="/result")
	public String getResult(@RequestParam(value="group") String group, @RequestParam(value="dose") float dose)
	{
	return out.getGroup_and_Dose(group,dose);	
	}
	
}
