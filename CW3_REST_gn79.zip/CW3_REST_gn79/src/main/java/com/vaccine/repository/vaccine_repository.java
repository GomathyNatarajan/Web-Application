package com.vaccine.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vaccine.model.vaccine;

public interface vaccine_repository extends JpaRepository<vaccine, Integer>{

	List<vaccine> findByVaccineGroup(String vaccineGroup);
}
