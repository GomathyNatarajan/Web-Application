package com.vaccine.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vaccine.model.volunteer;

public interface volunteer_repository extends JpaRepository<volunteer, Integer>{
	List <volunteer> findByVaccineGroup(String vaccineGroup);
	List <volunteer> findByDose(float Dose);
}
