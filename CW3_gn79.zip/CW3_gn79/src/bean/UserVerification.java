package bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.security.*;
import java.math.*;
import java.security.MessageDigest;

public class UserVerification {

	private static Connection connect = null;
	private static String host = "localhost";
	private static String database = "cw3";
	private static String username = "root";
	private static String password = "Positive";

	public static Connection getConnection() {
		if (connect == null) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				String conn_string = "jdbc:mysql://" + host + "/" + database;
				Connection connect = DriverManager.getConnection(conn_string, username, password);
				return connect;
			} catch (Exception ex) {
				return null;
				// ex.printStackTrace();
			}
		} else {
			return connect;
		}
	}

	public User checkUser(String user, String password) {
		System.out.println(user);
		System.out.println(password);
		String sql = "SELECT * FROM Admin WHERE Username=? AND PasswordHash=?";
		User u = null;
		String passwordHash = get_SHA_256_SecurePassword(password);
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql);) {
			pstmt.setString(1, user);
			pstmt.setString(2, passwordHash);
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					String uname = rs.getString("Username");
					String pass = rs.getString("PasswordHash");
					u = new User(uname,pass);
					break;
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		System.out.println(u);
		return u;
	}

	public Volunteer checkVolunteer(String user, String password) {
		System.out.println(user);
		System.out.println(password);
		String sql = "SELECT * FROM Volunteer WHERE email=? AND passwordHash=?";
		Volunteer v = null;
		String passwordHash = get_SHA_256_SecurePassword(password);
		System.out.println(passwordHash);
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql);) {
			pstmt.setString(1, user);
			pstmt.setString(2, passwordHash);
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					String uname = rs.getString("fullname");
					String email = rs.getString("email");
					String pass = rs.getString("PasswordHash");
					String address = rs.getString("address");
					String health = rs.getString("health_condition");
					String gender = rs.getString("gender");
					String age = rs.getString("age");
					System.out.println(uname);
					System.out.println(pass);
					v = new Volunteer(email,uname,gender,age,address,health,pass);
					break;
				}
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		System.out.println(v);
		return v;
	}
	
	public static String get_SHA_256_SecurePassword(String password) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(password.getBytes());
			return bytesToHex(md.digest());
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	private static String bytesToHex(byte[] bytes) {
		StringBuffer result = new StringBuffer();
		for (byte b : bytes)
			result.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
		return result.toString();
	}

	public boolean signUp(String email, String password, String fullname, int age, String gender, String address,
			String health) {
		boolean r = false;
		float dose = 0.0f;
		System.out.println(email);
		String passwordHash = get_SHA_256_SecurePassword(password);
		System.out.println(passwordHash);
		String sql = "INSERT INTO Volunteer VALUES(?,?,?,?,?,?,?,?,?,?)";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql);) {
			pstmt.setString(1, email);
			pstmt.setString(7, passwordHash);
			pstmt.setString(2, fullname);
			pstmt.setString(3, gender);
			pstmt.setInt(4, age);
			pstmt.setString(5, address);
			pstmt.setString(6, health);
			pstmt.setString(8, "");
			pstmt.setFloat(9, dose);
			pstmt.setString(10, "");
			pstmt.execute();
			System.out.println(pstmt.toString());
			r = true;
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		System.out.println(r);
		return r;
	}
	
	public boolean updateResult(String email, String vg, Float dose, String testResult) {
		boolean r = false;
		System.out.println(email);
		System.out.println(email);
		System.out.println(vg);
		System.out.println(dose);
		System.out.println(testResult);
		String sql = "UPDATE Volunteer SET vaccineGroup=?, dose=?, infected=? Where email=?";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql);) {
			pstmt.setString(4, email);
			pstmt.setString(1, vg);
			pstmt.setFloat(2, dose);
			pstmt.setString(3, testResult);
			pstmt.execute();
			r = true;
		}
		catch (SQLException ex) {
			ex.printStackTrace();
		
	}
		System.out.println(r);
		return r;
	}
	
	public VMReport getData() {
		VMReport vm = null;
		int Total_volunteers = 0;
		int Total_positive_cases = 0;
		int Total_PC_half_dose = 0;
		int Total_PC_dose = 0;
		int Total_vac_group = 0;
		int Total_unvac_group = 0;
		float Eff_rate_overall = 0;
		float Eff_rate_signle_dose = 0;
		float Eff_rate_half_dose = 0;
		int half_dose_A = 0;
		int half_dose_B = 0;
		int single_dose_A = 0;
		int single_dose_B = 0;
		
		
		
		String sql_tv = "SELECT COUNT(email) AS TotalCount FROM Volunteer";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_tv);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					Total_volunteers = Integer.parseInt(rs.getString("TotalCount"));
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		
		String sql_tpc = "SELECT COUNT(email) AS TotalCount FROM Volunteer WHERE infected='Positive'";
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_tpc);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					Total_positive_cases = Integer.parseInt(rs.getString("TotalCount"));
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		
		String sql_tvg = "SELECT COUNT(email) AS TotalCount FROM Volunteer WHERE infected='Positive' AND vaccineGroup='A'" ;
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_tvg);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					Total_vac_group = Integer.parseInt(rs.getString("TotalCount"));
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		
		String sql_tuvg = "SELECT COUNT(email) AS TotalCount FROM Volunteer WHERE infected='Positive' AND vaccineGroup='B'" ;
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_tuvg);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					Total_unvac_group = Integer.parseInt(rs.getString("TotalCount"));
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		
		String sql_half_dose_A = "SELECT COUNT(email) AS TotalCount FROM Volunteer WHERE infected='Positive' AND vaccineGroup='A' AND dose = '0.5'" ;
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_half_dose_A);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					half_dose_A = Integer.parseInt(rs.getString("TotalCount"));
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		
		String sql_single_dose_A = "SELECT COUNT(email) AS TotalCount FROM Volunteer WHERE infected='Positive' AND vaccineGroup='A' AND dose = '1'" ;
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_single_dose_A);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					single_dose_A = Integer.parseInt(rs.getString("TotalCount"));
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		
		String sql_half_dose_B = "SELECT COUNT(email) AS TotalCount FROM Volunteer WHERE infected='Positive' AND vaccineGroup='B' AND dose = '0.5'" ;
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_half_dose_B);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					half_dose_B = Integer.parseInt(rs.getString("TotalCount"));
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}
		
		
		String sql_single_dose_B = "SELECT COUNT(email) AS TotalCount FROM Volunteer WHERE infected='Positive' AND vaccineGroup='B' AND dose = '1'" ;
		try (Connection connect = getConnection(); PreparedStatement pstmt = connect.prepareStatement(sql_single_dose_B);) {
			try (ResultSet rs = pstmt.executeQuery();) {
				while (rs.next()) {
					single_dose_B = Integer.parseInt(rs.getString("TotalCount"));
				}
			}
		}
			catch (SQLException ex) {
				ex.printStackTrace();
			}

		
		if (Total_vac_group > Total_unvac_group)
		{
			if (Total_vac_group != 0) {
				Eff_rate_overall = (float)(Total_vac_group - Total_unvac_group) / Total_vac_group ;
				Eff_rate_overall = Eff_rate_overall * 100;
			}
		}
		else
		{
			if(Total_unvac_group != 0) {
				Eff_rate_overall = (float)(Total_unvac_group - Total_vac_group) / Total_unvac_group ;	
				Eff_rate_overall = Eff_rate_overall * 100;
			}
		}
		
		Total_PC_dose = single_dose_A+single_dose_B;
		if(single_dose_A > single_dose_B) {
			if(single_dose_A != 0) {
				Eff_rate_signle_dose = (float)(single_dose_A - single_dose_B) / single_dose_A ;
				Eff_rate_signle_dose = Eff_rate_signle_dose * 100;
			}
		}
			
		else {
			if(single_dose_B != 0) {
				Eff_rate_signle_dose = (float)(single_dose_B - single_dose_A)/single_dose_B;
				Eff_rate_signle_dose = Eff_rate_signle_dose * 100;

			}
		}
		
		
		Total_PC_half_dose = half_dose_A+half_dose_B;
		
		if(half_dose_A > half_dose_B) {
			if(half_dose_A != 0)
			{
				Eff_rate_half_dose = (float)(half_dose_A - half_dose_B) / half_dose_A ;
				Eff_rate_half_dose = Eff_rate_half_dose * 100;
			}
		}

		else {
			if(half_dose_B != 0)
			{
				Eff_rate_half_dose = (float)(half_dose_B - half_dose_A) / half_dose_B ;
				Eff_rate_half_dose = Eff_rate_half_dose * 100;
			}
		}
	
		System.out.println(Total_positive_cases + "Total");
		System.out.println(Total_PC_dose + "Dose");
		System.out.println(Total_PC_half_dose + "Half_dose");
		System.out.println();
		
		vm = new VMReport(Total_volunteers, Total_positive_cases, Total_vac_group, Total_unvac_group, Eff_rate_overall, 
							Eff_rate_signle_dose, Eff_rate_half_dose, Total_PC_half_dose, Total_PC_dose);
		
		System.out.println(vm.getTotalPC_dose());
		return vm;
		
	}
}
