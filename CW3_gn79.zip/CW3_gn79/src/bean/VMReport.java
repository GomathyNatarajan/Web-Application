package bean;

public class VMReport {
int total_volunteers;
int total_positive_cases;
int total_vac_group;
int total_unvac_group;
float eff_rate_overall;
float eff_rate_signle_dose;
float eff_rate_half_dose;
int total_pc_half_dose;
int total_pc_dose;

public VMReport(int total_volunteers,
int total_positive_cases,
int total_vac_group,
int total_unvac_group,
float eff_rate_overall,
float eff_rate_signle_dose,
float eff_rate_half_dose,
int total_pc_half_dose,
int total_pc_dose)
{
	super();
	this.total_volunteers = total_volunteers;
	this.total_positive_cases = total_positive_cases;
	this.total_vac_group = total_vac_group;
	this.total_unvac_group = total_unvac_group;
	this.eff_rate_overall = eff_rate_overall;
	this.eff_rate_signle_dose = eff_rate_signle_dose;
	this.eff_rate_half_dose = eff_rate_half_dose;
	this.total_pc_half_dose = total_pc_half_dose;
	this.total_pc_dose = total_pc_dose;
}

public int getTotalVolunteers()
{
	return total_volunteers;
}
public void setTotalVolunteers(int total_volunteers)
{
	this.total_volunteers = total_volunteers;	
}

public int getTotalPositiveCases()
{
	return total_positive_cases;
}
public void setTotalPositiveCases(int total_positive_cases)
{
	this.total_positive_cases = total_positive_cases;	
}

public int getTotalVacGroup()
{
	return total_vac_group;
}
public void setTotalTotalVacGroup(int total_vac_group)
{
	this.total_vac_group= total_vac_group;	
}

public int getTotalUnvacGroup()
{
	return total_unvac_group;
}
public void setTotalUnvacGroup(int total_unvac_group)
{
	this.total_unvac_group = total_unvac_group;	
}

public float getEffRateOverall()
{
	return eff_rate_overall;
}
public void setEffRateOverall(float eff_rate_overall)
{
	this.eff_rate_overall = eff_rate_overall;	
}

public float getEffRateSigle()
{
	return eff_rate_signle_dose;
}
public void setEffRateSigle(float eff_rate_signle_dose)
{
	this.eff_rate_signle_dose = eff_rate_signle_dose;	
}

public float getEffRateHalf()
{
	return eff_rate_half_dose;
}
public void setEffRateHalf(float eff_rate_half_dose)
{
	this.eff_rate_half_dose = eff_rate_half_dose;	
}

public int getTotalPC_half_dose()
{
	return total_pc_half_dose;
}
public void setTotalPC_half_dose(int total_pc_half_dose)
{
	this.total_pc_half_dose = total_pc_half_dose;	
}

public int getTotalPC_dose()
{
	return total_pc_dose;
}
public void setTotalPC_dose(int total_pc_dose)
{
	this.total_pc_dose = total_pc_dose;	
}
}
