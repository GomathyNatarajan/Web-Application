package bean;

public class Volunteer {

	public Volunteer(String Email, String Name, String Gender, String Age, String Address, String Health,String passwordHash)
	{
		super();
		this.Email = Email;
		this.passwordHash = passwordHash;
		this.Name = Name;
		this.Gender = Gender;
		this.Age = Age;
		this.Address = Address;
		this.Health = Health;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String Email)
	{
		this.Email = Email;
	}
	public String getpasswordHash() {
		return passwordHash;
	}
	public void setpasswordHash(String passwordHash)
	{
		this.passwordHash = passwordHash;
	}
	public String getName() {
		return Name;
	}
	public void setName(String Name)
	{
		this.Name = Name;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String Gender)
	{
		this.Gender = Gender;
	}
	public String getAge() {
		return Age;
	}
	public void setAge(String Age)
	{
		this.Age = Age;
	}
	
	public String getAddress() {
		return Address;
	}
	public void setAddress(String Address)
	{
		this.Address = Address;
	}
	public String getHealth() {
		return Health;
	}
	public void setHealth(String Health)
	{
		this.Health = Health;
	}
	String Email;
	String passwordHash;
	String Name;
	String Age;
	String Gender;
	String Address;
	String Health;
}
