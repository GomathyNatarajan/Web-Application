package cw3_gn79;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Volunteer;
import bean.UserVerification;

public class Volunteer_Report extends HttpServlet {
	public void doGet(HttpServletRequest req, 
	        HttpServletResponse res) 
        throws ServletException, IOException {
		
		
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
		boolean vs;
		PrintWriter out = res.getWriter();
		String email = req.getParameter("email");
		String vg = req.getParameter("vg");
		Float dose = Float.parseFloat(req.getParameter("dose"));
		String testResult = req.getParameter("testResult");
		UserVerification dbOperator = new UserVerification();	
		HttpSession se = req.getSession();
		vs = dbOperator.updateResult(email,vg,dose,testResult);
		if(vs==true)
		{
			res.sendRedirect("../success.jsp?id=1");
		}
		else {
			res.sendRedirect("../error.jsp?errorid=3");
			out.close();
		}
	}

}
