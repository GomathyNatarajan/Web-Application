package cw3_gn79;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Volunteer;
import bean.UserVerification;

public class Volunteer_Signin 
	extends HttpServlet {
		public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

			PrintWriter out = res.getWriter();
			String uname = req.getParameter("uname");
			
			String psw = req.getParameter("psw");

			UserVerification dbOperator = new UserVerification();
			Volunteer v;
			v = dbOperator.checkVolunteer(uname, psw);
			HttpSession se = req.getSession();

			if (v != null) {
				se.setAttribute("Volunteer", v);
				res.sendRedirect("../V_Report.jsp");
			} else {
				res.sendRedirect("../error.jsp?errorid=1");
				out.close();
			}
			
		}

		public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
			doGet(req, res);
		}
}
