package cw3_gn79;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Volunteer;
import bean.UserVerification;
public class Volunteer_Signup extends HttpServlet {
	public void doGet(HttpServletRequest req, 
	        HttpServletResponse res) 
        throws ServletException, IOException {
		
		boolean vs;
		PrintWriter out = res.getWriter();	
		String email=req.getParameter("email");
		String password = req.getParameter("psw");
		String fullname=req.getParameter("name");
		int age = Integer.parseInt(req.getParameter("age"));
		String gender = req.getParameter("gender");
		String address = req.getParameter("address");
		String health = req.getParameter("health");
		
		UserVerification dbOperator = new UserVerification();	
		HttpSession se = req.getSession();
		vs = dbOperator.signUp(email, password, fullname, age, gender, address, health);
		if (vs == true)
		{
			res.sendRedirect("../success.jsp?id=1");
		}
		else {
			res.sendRedirect("../error.jsp?errorid=3");
			out.close();
		}
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}

}
